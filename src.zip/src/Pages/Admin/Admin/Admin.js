import React from 'react';

const Admin = () => {
    return (
        <div>
            <h2>This is admin</h2>
        </div>
    );
};

export default Admin;