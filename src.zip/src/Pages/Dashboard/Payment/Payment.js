import React from 'react';

const Payment = () => {
    return (
        <div className='my-5 p-5 text-danger'>
            <h2>Payment System will be Coooming sooooon .......</h2>
        </div>
    );
};

export default Payment;